import withCSS from '@zeit/next-css';

module.exports = withCSS({})