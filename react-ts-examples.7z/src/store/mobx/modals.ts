import { observable, action } from "mobx";


export interface IModalStore {
  isOpen: boolean
  show(): void
  close(): void
}


class Modals implements IModalStore {
  @observable public isOpen: boolean = false;

  @action.bound
  show(): void {
    this.isOpen = true;
  }

  @action.bound
  close(): void {
    this.isOpen = false;
  }
}

export const createModalStore = () => new Modals();