import React, { FC } from 'react';
import { createPortal } from 'react-dom';


const ModalContainer: FC = (props): JSX.Element => {
  const container = document.querySelector('#modal-container');

  return createPortal(
    props.children,
    container as HTMLElement
  );
}

export default ModalContainer;