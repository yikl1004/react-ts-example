import React, { Fragment } from 'react';
import './Modal.scss';
import { useModals } from 'store/mobx';
import { CSSTransition } from 'react-transition-group';

const Modal = () => {

  const modals = useModals();

  return (
    <Fragment>
      <CSSTransition
      in={modals.isOpen}
      timeout={200}
      classNames="modal-anim"
      unmountOnExit
      >
        <div className="modal-dimm"/>
      </CSSTransition>
      <CSSTransition
        in={modals.isOpen}
        timeout={200}
        classNames="modal-anim"
        unmountOnExit
        onEnter={modals.show}
        onExited={modals.close}
      >
        <div className="modal">
          <p className="title">Modal Title</p>
          <div className="content">
            <p>
              이것은 지금 모달인데 아무말이나 넣고 있습니다. 쓸말이 없는데 넣어야 하니까 넣는거에요 그래야 테스트를 하죠.
            </p>
          </div>
          <div className="button-wrap">
            <button onClick={modals.close}> 닫기 </button>
          </div>
        </div>
      </CSSTransition>
    </Fragment>
  )
}
export default Modal;