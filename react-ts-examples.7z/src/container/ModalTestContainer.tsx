import React, { FC, Props, Fragment } from 'react';
import ModalContainer from 'components/modal/ModalContainer';
import Modal from 'components/modal';
import { IModalStore } from 'store/mobx/modals';
import { useModals } from 'store/mobx';


interface IProps {
  [key: string]: any;
}

const ModalTestContainer: FC<IProps> = (props: IProps): JSX.Element => {

  const modals: IModalStore = useModals();

  const handleModal = (): void => {
    if ( modals.isOpen ) {
      modals.close();
    } else {
      modals.show();
    }
  };

  return (
    <Fragment>
      <button onClick={handleModal}>modal handling</button>
      <p>{ modals.isOpen.toString() }</p>
      <ModalContainer>
        <Modal />
      </ModalContainer>
    </Fragment>
  )
}

export default ModalTestContainer;