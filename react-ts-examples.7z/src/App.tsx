// default
import React, { FC, Component, FunctionComponent } from 'react';
import { Router, Route, Link } from 'react-router-dom';
import { createBrowserHistory } from 'history';

// components
import TodoListContainer from 'container/TodoListContainer';
import ModalTestContainer from 'container/ModalTestContainer';


interface IMenuItem {
  path: string
  name: string
  component?: any
  exact?: boolean
}

const App: FC = (): JSX.Element => {
  const menus: IMenuItem[] = [
    { path: '/', name: 'Home', exact: true },
    { path: '/todolist', name: 'Todo List', component: TodoListContainer },
    { path: '/modaltest', name: 'modal test', component: ModalTestContainer }
  ];

  return (
    <div className="App">
      <header>
        <h1>Hello, World!</h1>
        <Router history={createBrowserHistory()}>
          <nav>
            <ul>
              { menus.map((menu: IMenuItem, index: number): JSX.Element => {
                let props = { exact: menu.exact ? menu.exact.toString() : "false" };
                  return (
                    <li key={index}>
                      <Link to={menu.path} {...props}>
                        { menu.name }
                      </Link>
                    </li>
                  )})
              }
            </ul>
          </nav>
          { menus.map((menu: IMenuItem, index: number): JSX.Element => {
            // let props = { exact: menu.exact ? menu.exact.toString() : "false" };
            if ( menu.path === '/' ) {
              return <Route path="/" exact />
            } else {
              return <Route path={ menu.path } component={ menu.component } />
            }
          })}
          <Route path="/todolist" component={ TodoListContainer } />
        </Router>
      </header>
    </div>
  );
}

export default App;
