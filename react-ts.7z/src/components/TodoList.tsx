import * as React from 'react'
import TodoItem from './TodoItem';

interface IProps {
  [key: string]: any
}

interface ITodoItemState {
  id: number;
  text: string;
  done: boolean;
}

interface IState {
  input: string;
  todoItems: ITodoItemState[];
}

class TodoList extends React.Component<IProps, IState> {
  public nextTodoId: number = 0;

  public state: IState = {
    input: '',
    todoItems: []
  };

  public onToggle = (id: number): void => {
    const {
      todoItems
    } = this.state;
    const nextTodoItems: ITodoItemState[] = todoItems.map(item => {
      if (item.id === id) {
        item.done = !item.done
      }
      return item;
    });

    this.setState({
      todoItems: nextTodoItems
    });
  }

  public onSubmit = (e: React.FormEvent < HTMLFormElement > ): void => {
    e.preventDefault();
    const {
      todoItems,
      input
    } = this.state;
    const newItem: ITodoItemState = {
      done: false,
      id: this.nextTodoId++,
      text: input,
    };
    const nextTodoItems: ITodoItemState[] = todoItems.concat(newItem);
    this.setState({
      input: '',
      todoItems: nextTodoItems
    });
  }

  public onRemove = (id: number): void => {
    const {
      todoItems
    } = this.state;
    const nextTodoItems: ITodoItemState[] = todoItems.filter(item => item.id !== id);
    this.setState({
      todoItems: nextTodoItems
    });
  }

  public onChange = (e: React.FormEvent < HTMLInputElement > ): void => {
    const {
      value
    } = e.currentTarget;
    this.setState({
      input: value
    });
  }

  public render() {
    const {
      onSubmit,
      onChange,
      onToggle,
      onRemove
    } = this;
    const {
      input,
      todoItems
    } = this.state;

    const todoItemList: React.ReactElement[] = todoItems.map(
      todo => (
        <TodoItem
          key={todo.id}
          done={todo.done}
          onToggle={() => onToggle(todo.id)}
          onRemove={() => onRemove(todo.id)}
          text={todo.text}
        />
      )
    );

    return (
      <div>
        <h1>오늘 뭐하지 ?</h1>
        <form onSubmit={onSubmit}>
          <input onChange={onChange} value={input} />
          <button type="submit">추가하기</button>
        </form>
        <ul>
          { todoItemList }
        </ul>
      </div>
    );
  }

}

export default TodoList;